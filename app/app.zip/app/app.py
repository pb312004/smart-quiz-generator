from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import random

app = Flask(__name__)


questions_df = pd.read_csv('question.csv')


current_round = 0
score = 0

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/question', methods=['GET', 'POST'])
def question():
    global current_round, score
    if request.method == 'POST':
        user_answer = request.form['answer']
        correct_answer = questions_df.iloc[current_round]['Column7']
        if user_answer == correct_answer:
            score += 1
        current_round += 1
        if current_round == 10:
            return redirect(url_for('result'))
    current_question = questions_df.iloc[current_round]
    question_text = current_question['Column2']
    options = [current_question['Column3'], current_question['Column4'], current_question['Column5'], current_question['Column6']]
    return render_template('question.html', question_text=question_text, options=options)

@app.route('/result')
def result():
    global score
    final_score = score
    score = 0  # Reset score for new game
    return render_template('result.html', final_score=final_score)

if __name__ == '__main__':
    app.run(debug=True)
